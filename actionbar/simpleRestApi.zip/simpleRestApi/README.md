This is a simple REST api page that can get, post, put and delete a user and show all users on screen
The user fields are: id (unique auto_incremented), name, bio, facebook_id
At the moment it's written only with Jquery, no framework (e.g React, Angular etc..)

Setup:
npm i

run:
1. node index.js or nodemon
2. navigate to http://localhost:3000
